import express from "express";
import {
  getVendorOverview,
  getOrdersByVendor,
  getOrderByIdForVendor,
  
} from "../../controllers/vendorShop/vendorDashboard.js";
import {
  authMiddleware,
  vendorMiddleware,
  adminMiddleware,
} from "../../middlewares/auth.js";

const router = express.Router();
router.get("/dashboard/overview", vendorMiddleware, getVendorOverview);
router.get("/dashboard/orders", vendorMiddleware, getOrdersByVendor);
router.get(
  "/dashboard/orders/:orderId",
  vendorMiddleware,
  getOrderByIdForVendor,
);

export default router;
